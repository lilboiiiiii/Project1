package server.view;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;
import server.controller.ServerController;
import server.model.ChatServer;

/**
 * JavaFX Application entry point for TCPServer.
 * Wires Model → Controller → View, then shows the window.
 */
public class ServerApp extends Application {

    private ServerController controller;

    @Override
    public void start(Stage primaryStage) {
        // 1. Model
        ChatServer model = new ChatServer();

        // 2. View
        ServerView view = new ServerView();

        // 3. Controller
        controller = new ServerController(model, view);
        view.setController(controller);

        // 4. Scene
        Scene scene = new Scene(view, 860, 560);
        primaryStage.setTitle("TCP Chat Server");
        primaryStage.setScene(scene);
        primaryStage.setOnCloseRequest(e -> {
            controller.stopServer();
            Platform.exit();
        });
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
