package server.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import server.controller.ServerController;
import server.model.ChatServer;
import server.model.ServerConfig;

import java.util.Random;

/**
 * JavaFX View for the chat server.
 * Displays: status indicator, activity log, connected-users list.
 * All server logic lives in ChatServer (model) — this class is purely presentational.
 */
public class ServerView extends BorderPane {

    // ── palette ──────────────────────────────────────────────────────────────
    private static final String BG_DARK   = "#1a1d2e";
    private static final String BG_PANEL  = "#252840";
    private static final String BG_CARD   = "#2e3250";
    private static final String ACCENT    = "#7c6af7";   // indigo-violet
    private static final String ACCENT2   = "#56cfb2";   // teal
    private static final String TEXT_MAIN = "#e8e9f3";
    private static final String TEXT_DIM  = "#8a8fa8";

    private static final String[] USER_COLORS = {
            "#f87171","#fb923c","#fbbf24","#a3e635",
            "#34d399","#22d3ee","#818cf8","#e879f9"
    };
    private final Random rng = new Random();

    // ── widgets ───────────────────────────────────────────────────────────────
    private final TextArea   logArea    = new TextArea();
    private final ListView<String> userList = new ListView<>();
    private final Label      statusLabel= new Label("Offline");
    private final Circle     statusDot  = new Circle(7);
    private final Button     startBtn   = new Button("Start Server");

    private ServerController controller;

    // ─────────────────────────────────────────────────────────────────────────

    public ServerView() {
        buildUI();
    }

    /** Called after controller is created so the button has something to call. */
    public void setController(ServerController ctrl) {
        this.controller = ctrl;
    }

    // ── build ─────────────────────────────────────────────────────────────────

    private void buildUI() {
        setStyle("-fx-background-color: " + BG_DARK + ";");

        setTop(buildHeader());
        setCenter(buildCenter());
        setRight(buildSidebar());

        // Wire Start button
        startBtn.setOnAction(e -> {
            if (controller != null) {
                ServerConfig cfg = new ServerConfig();
                controller.startServer(cfg.getPort());
                startBtn.setDisable(true);
            }
        });
    }

    private HBox buildHeader() {
        Label title = new Label("TCP Chat Server");
        title.setStyle("-fx-text-fill: " + TEXT_MAIN + "; -fx-font-size: 20px; "
                + "-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");

        statusDot.setFill(Color.web("#ef4444"));
        statusLabel.setStyle("-fx-text-fill: " + TEXT_DIM + "; -fx-font-size: 13px;");

        HBox statusBox = new HBox(6, statusDot, statusLabel);
        statusBox.setAlignment(Pos.CENTER);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        startBtn.setStyle(btnStyle(ACCENT));
        startBtn.setOnMouseEntered(e -> startBtn.setStyle(btnStyle("#9784f9")));
        startBtn.setOnMouseExited(e  -> startBtn.setStyle(btnStyle(ACCENT)));

        HBox header = new HBox(16, title, spacer, statusBox, startBtn);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(16, 20, 16, 20));
        header.setStyle("-fx-background-color: " + BG_PANEL + "; "
                + "-fx-border-color: " + ACCENT + "; -fx-border-width: 0 0 2 0;");
        return header;
    }

    private VBox buildCenter() {
        Label logLabel = new Label("▸  Activity Log");
        logLabel.setStyle("-fx-text-fill: " + ACCENT2 + "; -fx-font-size: 12px; "
                + "-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");

        logArea.setEditable(false);
        logArea.setWrapText(true);
        logArea.setStyle(
                "-fx-control-inner-background: " + BG_CARD + ";"
                + "-fx-text-fill: " + TEXT_MAIN + ";"
                + "-fx-font-family: 'Consolas', 'Courier New', monospace;"
                + "-fx-font-size: 13px;"
                + "-fx-background-color: transparent;");
        VBox.setVgrow(logArea, Priority.ALWAYS);

        VBox center = new VBox(8, logLabel, logArea);
        center.setPadding(new Insets(16, 12, 16, 20));
        center.setStyle("-fx-background-color: " + BG_DARK + ";");
        return center;
    }

    private VBox buildSidebar() {
        Label usersLabel = new Label("⬤  Connected Users");
        usersLabel.setStyle("-fx-text-fill: " + ACCENT + "; -fx-font-size: 12px; "
                + "-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");

        userList.setStyle(
                "-fx-background-color: " + BG_CARD + ";"
                + "-fx-control-inner-background: " + BG_CARD + ";"
                + "-fx-text-fill: " + TEXT_MAIN + ";");
        userList.setPrefWidth(200);
        VBox.setVgrow(userList, Priority.ALWAYS);

        // Custom cell with random background colour per user
        userList.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("-fx-background-color: transparent;");
                } else {
                    setText("  " + item);
                    String color = USER_COLORS[Math.abs(item.hashCode()) % USER_COLORS.length];
                    setStyle("-fx-background-color: " + color + "22;"
                            + "-fx-text-fill: " + TEXT_MAIN + ";"
                            + "-fx-font-family: 'Segoe UI';"
                            + "-fx-font-size: 13px;"
                            + "-fx-padding: 6 8 6 8;"
                            + "-fx-border-color: " + color + "55;"
                            + "-fx-border-width: 0 0 1 3;");
                }
            }
        });

        VBox sidebar = new VBox(8, usersLabel, userList);
        sidebar.setPadding(new Insets(16, 20, 16, 12));
        sidebar.setStyle("-fx-background-color: " + BG_PANEL + ";"
                + "-fx-border-color: " + ACCENT + "; -fx-border-width: 0 0 0 2;");
        return sidebar;
    }

    // ── view API ──────────────────────────────────────────────────────────────

    public void appendLog(String message) {
        logArea.appendText(message + "\n");
    }

    public void addClient(String username) {
        if (!userList.getItems().contains(username))
            userList.getItems().add(username);
    }

    public void removeClient(String username) {
        userList.getItems().remove(username);
    }

    public void setStatus(boolean online) {
        if (online) {
            statusDot.setFill(Color.web("#22c55e"));
            statusLabel.setText("Online");
            statusLabel.setStyle("-fx-text-fill: #22c55e; -fx-font-size: 13px;");
        } else {
            statusDot.setFill(Color.web("#ef4444"));
            statusLabel.setText("Offline");
            statusLabel.setStyle("-fx-text-fill: " + TEXT_DIM + "; -fx-font-size: 13px;");
        }
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private String btnStyle(String bg) {
        return "-fx-background-color: " + bg + ";"
                + "-fx-text-fill: white;"
                + "-fx-font-size: 13px;"
                + "-fx-font-family: 'Segoe UI';"
                + "-fx-padding: 8 18 8 18;"
                + "-fx-background-radius: 6;"
                + "-fx-cursor: hand;";
    }
}
