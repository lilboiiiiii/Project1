package server.controller;

import server.model.ChatServer;
import server.model.ServerConfig;
import server.view.ServerView;
import javafx.application.Platform;

import java.io.IOException;

/**
 * Controller: wires ChatServer (Model) to ServerView (View).
 * Translates model callbacks into JavaFX Platform.runLater() calls.
 */
public class ServerController {

    private final ChatServer model;
    private final ServerView view;

    public ServerController(ChatServer model, ServerView view) {
        this.model = model;
        this.view  = view;
        wireCallbacks();
    }

    private void wireCallbacks() {
        model.setOnLog(msg ->
                Platform.runLater(() -> view.appendLog(msg)));

        model.setOnClientConnected(username ->
                Platform.runLater(() -> view.addClient(username)));

        model.setOnClientDisconnected(username ->
                Platform.runLater(() -> view.removeClient(username)));
    }

    /** Called by the View's Start button. */
    public void startServer(int port) {
        model.configure(port);
        try {
            model.start();
            Platform.runLater(() -> view.setStatus(true));
        } catch (IOException e) {
            Platform.runLater(() -> view.appendLog("ERROR: " + e.getMessage()));
        }
    }

    /** Called when the application closes. */
    public void stopServer() {
        model.stop();
    }
}
