package server.model;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Loads network configuration from server.properties on the classpath.
 * Keeps hard-coded values out of the source code.
 */
public class ServerConfig {

    private static final String CONFIG_FILE = "/server.properties";

    private int port = 3000; // sensible default

    public ServerConfig() {
        load();
    }

    private void load() {
        try (InputStream is = getClass().getResourceAsStream(CONFIG_FILE)) {
            if (is == null) {
                System.err.println("[Config] " + CONFIG_FILE + " not found — using defaults.");
                return;
            }
            Properties props = new Properties();
            props.load(is);
            port = Integer.parseInt(props.getProperty("server.port", "3000").trim());
        } catch (IOException | NumberFormatException e) {
            System.err.println("[Config] Failed to parse config: " + e.getMessage());
        }
    }

    public int getPort() { return port; }
}
