package server.model;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/**
 * Core server model.
 * Accepts incoming TCP connections and spawns a ClientHandler thread for each.
 * Fires callbacks to the View via Consumer lambdas — no JavaFX import here.
 */
public class ChatServer {

    private int port;
    private ServerSocket serverSocket;
    private final List<ClientHandler> clients = new CopyOnWriteArrayList<>();
    private final ExecutorService threadPool = Executors.newCachedThreadPool();

    // Callbacks set by the Controller/View
    private Consumer<String>  onLog;
    private Consumer<String>  onClientConnected;
    private Consumer<String>  onClientDisconnected;

    // ------------------------------------------------------------------ setup

    public void configure(int port) {
        this.port = port;
    }

    public void setOnLog(Consumer<String> cb)               { this.onLog = cb; }
    public void setOnClientConnected(Consumer<String> cb)   { this.onClientConnected = cb; }
    public void setOnClientDisconnected(Consumer<String> cb){ this.onClientDisconnected = cb; }

    // ------------------------------------------------------------------ start

    public void start() throws IOException {
        serverSocket = new ServerSocket(port);
        log("Server started on port " + port);
        log("Waiting for clients…");

        // Accept loop runs on its own daemon thread so it doesn't block JavaFX
        Thread acceptThread = new Thread(() -> {
            while (!serverSocket.isClosed()) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    ClientHandler handler = new ClientHandler(clientSocket, this);
                    threadPool.execute(handler);
                } catch (IOException e) {
                    if (!serverSocket.isClosed()) log("Accept error: " + e.getMessage());
                }
            }
        });
        acceptThread.setDaemon(true);
        acceptThread.start();
    }

    public void stop() {
        try {
            if (serverSocket != null) serverSocket.close();
            threadPool.shutdownNow();
        } catch (IOException ignored) {}
    }

    // ------------------------------------------------------------------ client registry

    void registerClient(ClientHandler handler) {
        clients.add(handler);
        log("Welcome " + handler.getUsername());
        if (onClientConnected != null) onClientConnected.accept(handler.getUsername());
    }

    void removeClient(ClientHandler handler) {
        clients.remove(handler);
        log(handler.getUsername() + " disconnected.");
        if (onClientDisconnected != null) onClientDisconnected.accept(handler.getUsername());
    }

    /** Broadcast to all clients except the optional sender. */
    void broadcast(String message, ClientHandler sender, String senderName) {
        log("[BROADCAST] " + message);
        for (ClientHandler c : clients) {
            if (c != sender) c.sendMessage(message);
        }
        // Echo formatted message back to the sender too (they see their own message)
        if (sender != null) sender.sendMessage(message);
    }

    /** Returns comma-separated list of active usernames. */
    String getActiveUsernames() {
        if (clients.isEmpty()) return "(none)";
        StringJoiner sj = new StringJoiner(", ");
        clients.forEach(c -> sj.add(c.getUsername()));
        return sj.toString();
    }

    // ------------------------------------------------------------------ helpers

    private void log(String msg) {
        if (onLog != null) onLog.accept(msg);
    }

    public List<String> getConnectedUsernames() {
        List<String> names = new ArrayList<>();
        clients.forEach(c -> names.add(c.getUsername()));
        return names;
    }

    public boolean isRunning() {
        return serverSocket != null && !serverSocket.isClosed();
    }
}
