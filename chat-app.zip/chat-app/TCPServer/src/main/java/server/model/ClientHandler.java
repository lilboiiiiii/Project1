package server.model;

import java.io.*;
import java.net.Socket;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Handles all I/O for a single connected client on its own thread.
 * Part of the Model layer — no JavaFX imports.
 */
public class ClientHandler implements Runnable {

    private static final DateTimeFormatter TIME_FMT =
            DateTimeFormatter.ofPattern("HH:mm");

    private final Socket socket;
    private final ChatServer server;

    private PrintWriter out;
    private BufferedReader in;
    private String username;
    private boolean readOnly = false;

    public ClientHandler(Socket socket, ChatServer server) {
        this.socket = socket;
        this.server = server;
    }

    @Override
    public void run() {
        try {
            out = new PrintWriter(new BufferedWriter(
                    new OutputStreamWriter(socket.getOutputStream())), true);
            in  = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));

            // First line from client is the username (may be blank → read-only)
            username = in.readLine();
            if (username == null) { cleanup(); return; }

            if (username.isBlank()) {
                readOnly = true;
                username = "Guest-" + socket.getPort();
                out.println("[SERVER] READ-ONLY MODE: you can receive but not send messages.");
            } else {
                server.broadcast("[SERVER] " + username + " has joined the chat.",
                        null, username);
            }

            server.registerClient(this);

            // Main read loop
            String line;
            while ((line = in.readLine()) != null) {
                if (line.equalsIgnoreCase("end") || line.equalsIgnoreCase("bye")) {
                    out.println("[SERVER] Goodbye, " + username + "!");
                    break;
                }

                if (readOnly) {
                    out.println("[SERVER] You are in READ-ONLY mode.");
                    continue;
                }

                if (line.equalsIgnoreCase("allUsers")) {
                    out.println("[SERVER] Active users: " + server.getActiveUsernames());
                    continue;
                }

                String timestamp = LocalTime.now().format(TIME_FMT);
                String formatted = "[" + timestamp + "] " + username + ": " + line;
                server.broadcast(formatted, this, username);
            }

        } catch (IOException e) {
            // Client disconnected unexpectedly — handle silently
        } finally {
            cleanup();
        }
    }

    /** Send a message directly to this client. */
    public void sendMessage(String message) {
        if (out != null) out.println(message);
    }

    public String getUsername() { return username; }
    public boolean isReadOnly()  { return readOnly; }

    private void cleanup() {
        try {
            server.removeClient(this);
            if (!readOnly) {
                server.broadcast("[SERVER] " + username + " has left the chat.",
                        null, username);
            }
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException ignored) {}
    }
}
