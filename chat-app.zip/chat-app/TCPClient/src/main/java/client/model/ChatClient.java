package client.model;

import java.io.*;
import java.net.Socket;
import java.util.function.Consumer;

/**
 * Core client model.
 * Opens a TCP connection to the server, sends messages, and listens for
 * incoming messages on a background thread.
 * No JavaFX imports — fires callbacks for the View layer.
 */
public class ChatClient {

    private Socket       socket;
    private PrintWriter  out;
    private BufferedReader in;

    private String  username;
    private boolean connected = false;

    // Callbacks (set by Controller)
    private Consumer<String>  onMessageReceived;
    private Runnable          onDisconnected;

    // ── config ────────────────────────────────────────────────────────────────

    public void setOnMessageReceived(Consumer<String> cb) { this.onMessageReceived = cb; }
    public void setOnDisconnected(Runnable cb)            { this.onDisconnected    = cb; }

    // ── connect ───────────────────────────────────────────────────────────────

    /**
     * Opens the connection and sends the username as the first line.
     * Starts the background listener thread.
     * @throws IOException if connection fails
     */
    public void connect(String host, int port, String username) throws IOException {
        this.username = username;
        socket = new Socket(host, port);
        out    = new PrintWriter(new BufferedWriter(
                     new OutputStreamWriter(socket.getOutputStream())), true);
        in     = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        // The server's protocol expects username as the very first line
        out.println(username == null ? "" : username);
        connected = true;

        // Start background reader
        Thread reader = new Thread(this::readLoop);
        reader.setDaemon(true);
        reader.start();
    }

    // ── send ──────────────────────────────────────────────────────────────────

    /**
     * Sends a message to the server.
     * "end" / "bye" will trigger a graceful disconnect.
     */
    public void sendMessage(String text) {
        if (!connected || out == null) return;
        out.println(text);
        if (text.equalsIgnoreCase("end") || text.equalsIgnoreCase("bye")) {
            disconnect();
        }
    }

    // ── disconnect ────────────────────────────────────────────────────────────

    public void disconnect() {
        connected = false;
        try { if (socket != null) socket.close(); } catch (IOException ignored) {}
        if (onDisconnected != null) onDisconnected.run();
    }

    // ── internals ─────────────────────────────────────────────────────────────

    private void readLoop() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                if (onMessageReceived != null) onMessageReceived.accept(line);
            }
        } catch (IOException e) {
            // connection closed
        } finally {
            if (connected) disconnect();
        }
    }

    // ── getters ───────────────────────────────────────────────────────────────

    public boolean isConnected() { return connected; }
    public String  getUsername() { return username;  }
}
