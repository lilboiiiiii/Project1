package client.model;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Loads host/port from client.properties on the classpath.
 * Command-line arguments (passed via main args) override these values.
 */
public class ClientConfig {

    private static final String CONFIG_FILE = "/client.properties";

    private String host = "localhost";
    private int    port = 3000;

    public ClientConfig() { load(); }

    /** Override with CLI args: java TCPClient <host> <port> */
    public ClientConfig(String[] args) {
        load();
        if (args.length >= 2) {
            host = args[0];
            try { port = Integer.parseInt(args[1]); }
            catch (NumberFormatException e) {
                System.err.println("[Config] Invalid port arg '" + args[1] + "' — using default.");
            }
        }
    }

    private void load() {
        try (InputStream is = getClass().getResourceAsStream(CONFIG_FILE)) {
            if (is == null) return;
            Properties p = new Properties();
            p.load(is);
            host = p.getProperty("server.host", host).trim();
            port = Integer.parseInt(p.getProperty("server.port", String.valueOf(port)).trim());
        } catch (IOException | NumberFormatException e) {
            System.err.println("[Config] " + e.getMessage());
        }
    }

    public String getHost() { return host; }
    public int    getPort() { return port; }
}
