package client.controller;

import client.model.ChatClient;
import client.model.ClientConfig;
import client.view.ClientView;
import javafx.application.Platform;

import java.io.IOException;

/**
 * Controller: wires ChatClient (Model) ↔ ClientView (View).
 * Translates model events into Platform.runLater() view updates.
 */
public class ClientController {

    private final ChatClient  model;
    private final ClientView  view;
    private final ClientConfig config;

    public ClientController(ChatClient model, ClientView view, ClientConfig config) {
        this.model  = model;
        this.view   = view;
        this.config = config;
        wireCallbacks();
    }

    private void wireCallbacks() {
        model.setOnMessageReceived(msg ->
                Platform.runLater(() -> view.appendMessage(msg)));

        model.setOnDisconnected(() ->
                Platform.runLater(() -> {
                    view.setOnline(false);
                    view.appendMessage("--- Disconnected from server ---");
                    view.lockInput();
                }));
    }

    // ── actions called by the View ─────────────────────────────────────────

    /** Called when the user submits their username on the login screen. */
    public void connect(String username) {
        try {
            model.connect(config.getHost(), config.getPort(), username);
            Platform.runLater(() -> {
                view.setOnline(true);
                if (username == null || username.isBlank()) {
                    view.lockInput(); // read-only mode
                    view.appendMessage("[LOCAL] Connected in READ-ONLY mode.");
                } else {
                    view.appendMessage("[LOCAL] Connected as " + username);
                }
            });
        } catch (IOException e) {
            Platform.runLater(() ->
                    view.showError("Cannot connect to server: " + e.getMessage()));
        }
    }

    /** Called when the user clicks Send or presses Enter. */
    public void sendMessage(String text) {
        if (text == null || text.isBlank()) return;
        model.sendMessage(text);
    }

    /** Called on window close. */
    public void disconnect() {
        model.disconnect();
    }
}
