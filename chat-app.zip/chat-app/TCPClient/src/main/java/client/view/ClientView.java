package client.view;

import client.controller.ClientController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 * JavaFX View for the chat client.
 * Presents: login overlay → main chat area with message history, input bar,
 * and online/offline status indicator.
 * All network logic lives in ChatClient — this file is purely presentational.
 */
public class ClientView extends StackPane {

    // ── palette ──────────────────────────────────────────────────────────────
    private static final String BG_DARK   = "#0f1117";
    private static final String BG_PANEL  = "#1a1d2e";
    private static final String BG_INPUT  = "#252840";
    private static final String BG_BUBBLE = "#2e3250";
    private static final String ACCENT    = "#7c6af7";
    private static final String ACCENT2   = "#56cfb2";
    private static final String TEXT_MAIN = "#e8e9f3";
    private static final String TEXT_DIM  = "#8a8fa8";

    // ── widgets ───────────────────────────────────────────────────────────────
    private final TextArea  chatArea   = new TextArea();
    private final TextField inputField = new TextField();
    private final Button    sendBtn    = new Button("Send");
    private final Label     statusLbl  = new Label("Offline");
    private final Circle    statusDot  = new Circle(6);

    // Login overlay
    private final VBox      loginOverlay = new VBox();
    private final TextField usernameField = new TextField();

    private ClientController controller;

    // ─────────────────────────────────────────────────────────────────────────

    public ClientView() {
        buildMain();
        buildLoginOverlay();
    }

    public void setController(ClientController ctrl) {
        this.controller = ctrl;
    }

    // ── build ─────────────────────────────────────────────────────────────────

    private void buildMain() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: " + BG_DARK + ";");

        root.setTop(buildTopBar());
        root.setCenter(buildChatArea());
        root.setBottom(buildInputBar());

        getChildren().add(root);
    }

    private HBox buildTopBar() {
        Label title = new Label("Group Chat");
        title.setStyle("-fx-text-fill: " + TEXT_MAIN + "; -fx-font-size: 18px; "
                + "-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");

        statusDot.setFill(Color.web("#ef4444"));
        statusLbl.setStyle("-fx-text-fill: " + TEXT_DIM + "; -fx-font-size: 12px;");

        HBox statusBox = new HBox(6, statusDot, statusLbl);
        statusBox.setAlignment(Pos.CENTER);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox bar = new HBox(14, title, spacer, statusBox);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(14, 18, 14, 18));
        bar.setStyle("-fx-background-color: " + BG_PANEL + ";"
                + "-fx-border-color: " + ACCENT + "; -fx-border-width: 0 0 2 0;");
        return bar;
    }

    private VBox buildChatArea() {
        chatArea.setEditable(false);
        chatArea.setWrapText(true);
        chatArea.setStyle(
                "-fx-control-inner-background: " + BG_DARK + ";"
                + "-fx-text-fill: " + TEXT_MAIN + ";"
                + "-fx-font-family: 'Segoe UI', sans-serif;"
                + "-fx-font-size: 13.5px;"
                + "-fx-background-color: transparent;");
        VBox.setVgrow(chatArea, Priority.ALWAYS);

        VBox center = new VBox(chatArea);
        center.setPadding(new Insets(10, 14, 0, 14));
        center.setStyle("-fx-background-color: " + BG_DARK + ";");
        return center;
    }

    private HBox buildInputBar() {
        inputField.setPromptText("Type a message… ('allUsers', 'end', 'bye')");
        inputField.setStyle(
                "-fx-background-color: " + BG_INPUT + ";"
                + "-fx-text-fill: " + TEXT_MAIN + ";"
                + "-fx-prompt-text-fill: " + TEXT_DIM + ";"
                + "-fx-font-size: 13px;"
                + "-fx-background-radius: 8;"
                + "-fx-padding: 10 14 10 14;"
                + "-fx-border-width: 0;");
        HBox.setHgrow(inputField, Priority.ALWAYS);

        // Send on Enter
        inputField.setOnAction(e -> handleSend());

        sendBtn.setStyle(btnStyle(ACCENT));
        sendBtn.setOnMouseEntered(e -> sendBtn.setStyle(btnStyle("#9784f9")));
        sendBtn.setOnMouseExited(e  -> sendBtn.setStyle(btnStyle(ACCENT)));
        sendBtn.setOnAction(e -> handleSend());
        sendBtn.setMinWidth(80);

        HBox bar = new HBox(10, inputField, sendBtn);
        bar.setPadding(new Insets(12, 14, 14, 14));
        bar.setAlignment(Pos.CENTER);
        bar.setStyle("-fx-background-color: " + BG_PANEL + ";"
                + "-fx-border-color: " + ACCENT + "; -fx-border-width: 2 0 0 0;");
        return bar;
    }

    private void buildLoginOverlay() {
        loginOverlay.setAlignment(Pos.CENTER);
        loginOverlay.setSpacing(16);
        loginOverlay.setMaxWidth(340);
        loginOverlay.setMaxHeight(240);
        loginOverlay.setStyle(
                "-fx-background-color: " + BG_PANEL + ";"
                + "-fx-padding: 36 40 36 40;"
                + "-fx-background-radius: 14;"
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.6), 30, 0, 0, 8);");

        Label heading = new Label("Join Chat");
        heading.setStyle("-fx-text-fill: " + TEXT_MAIN + "; -fx-font-size: 22px; "
                + "-fx-font-weight: bold; -fx-font-family: 'Segoe UI';");

        Label sub = new Label("Enter a username, or leave blank for read-only mode.");
        sub.setWrapText(true);
        sub.setStyle("-fx-text-fill: " + TEXT_DIM + "; -fx-font-size: 12px; "
                + "-fx-font-family: 'Segoe UI'; -fx-text-alignment: center;");
        sub.setMaxWidth(260);

        usernameField.setPromptText("Username (optional)");
        usernameField.setStyle(
                "-fx-background-color: " + BG_INPUT + ";"
                + "-fx-text-fill: " + TEXT_MAIN + ";"
                + "-fx-prompt-text-fill: " + TEXT_DIM + ";"
                + "-fx-background-radius: 8;"
                + "-fx-padding: 10 14 10 14;"
                + "-fx-font-size: 13px;");
        usernameField.setMaxWidth(260);

        Button joinBtn = new Button("Connect");
        joinBtn.setStyle(btnStyle(ACCENT2.replace("56cfb2", "22b89a")));
        joinBtn.setMinWidth(120);
        joinBtn.setOnAction(e -> handleLogin());
        usernameField.setOnAction(e -> handleLogin());

        // Dim background
        Region dimmer = new Region();
        dimmer.setStyle("-fx-background-color: rgba(0,0,0,0.55);");
        dimmer.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

        loginOverlay.getChildren().addAll(heading, sub, usernameField, joinBtn);

        StackPane overlay = new StackPane(dimmer, loginOverlay);
        getChildren().add(overlay);
    }

    // ── event handlers ────────────────────────────────────────────────────────

    private void handleLogin() {
        if (controller != null) {
            String name = usernameField.getText().trim();
            // Remove the login overlay
            getChildren().removeIf(n -> n instanceof StackPane);
            controller.connect(name.isEmpty() ? "" : name);
        }
    }

    private void handleSend() {
        String text = inputField.getText().trim();
        if (!text.isEmpty() && controller != null) {
            controller.sendMessage(text);
            inputField.clear();
        }
    }

    // ── view API ──────────────────────────────────────────────────────────────

    public void appendMessage(String message) {
        chatArea.appendText(message + "\n");
    }

    public void setOnline(boolean online) {
        if (online) {
            statusDot.setFill(Color.web("#22c55e"));
            statusLbl.setText("Online");
            statusLbl.setStyle("-fx-text-fill: #22c55e; -fx-font-size: 12px;");
        } else {
            statusDot.setFill(Color.web("#ef4444"));
            statusLbl.setText("Offline");
            statusLbl.setStyle("-fx-text-fill: " + TEXT_DIM + "; -fx-font-size: 12px;");
        }
    }

    /** Disable the input bar (read-only or disconnected). */
    public void lockInput() {
        inputField.setDisable(true);
        sendBtn.setDisable(true);
        inputField.setPromptText("READ-ONLY: you can only receive messages.");
    }

    public void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        alert.setHeaderText("Connection Error");
        alert.showAndWait();
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private String btnStyle(String bg) {
        return "-fx-background-color: " + bg + ";"
                + "-fx-text-fill: white;"
                + "-fx-font-size: 13px;"
                + "-fx-font-family: 'Segoe UI';"
                + "-fx-padding: 9 18 9 18;"
                + "-fx-background-radius: 8;"
                + "-fx-cursor: hand;";
    }
}
