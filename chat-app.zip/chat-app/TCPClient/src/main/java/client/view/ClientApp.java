package client.view;

import client.controller.ClientController;
import client.model.ChatClient;
import client.model.ClientConfig;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * JavaFX Application entry point for TCPClient.
 *
 * Usage:  java TCPClient <ServerIPAddress> <PortNumber>
 * e.g.:   java TCPClient localhost 3000
 *
 * If no args are given, values from client.properties are used.
 */
public class ClientApp extends Application {

    private ClientController controller;

    @Override
    public void start(Stage primaryStage) {
        // Parse CLI args (passed through JavaFX via getParameters())
        String[] args = getParameters().getRaw().toArray(new String[0]);

        // 1. Config (CLI args override .properties)
        ClientConfig config = new ClientConfig(args);

        // 2. Model
        ChatClient model = new ChatClient();

        // 3. View
        ClientView view = new ClientView();

        // 4. Controller
        controller = new ClientController(model, view, config);
        view.setController(controller);

        // 5. Scene
        Scene scene = new Scene(view, 780, 520);
        primaryStage.setTitle("TCP Group Chat — " + config.getHost() + ":" + config.getPort());
        primaryStage.setScene(scene);
        primaryStage.setOnCloseRequest(e -> {
            controller.disconnect();
            Platform.exit();
        });
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
